package model;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Scanner;

/**
 * TCSS 360
 *
 * Represents the questions to be asked in the maze. Includes function that asks
 * the questions and returns true/false depending on User answer Requires
 * questions.db in TriviaMaze folder
 *
 * @author Tylor Franklin
 * @author Killian Hickey
 * @author Dino Jazvin
 *
 * @version 5/29/2021
 */
public class Question implements Serializable {

    // holds the type of question: Short (short),
    // true/false (tf), or multiple choice (mc)
    private String myType;

    // holds the actual question
    private String myQuestionText;

    // holds the correct answer
    private String myAnswer;

    // holds the different answers for multiple choice answers
    private String[] myMcAnswers;

    /**
     * Default constructor of a Question Grabs a random question and answer(s) from
     * the questions database
     */
    public Question() {

        Connection connection = null;
        // Attempt to connect to the database and create the question
        try {
            // create a database connection
            connection = DriverManager.getConnection("jdbc:sqlite:questions.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30); // set timeout to 30 sec.

            // get number of questions
            ResultSet rs = statement.executeQuery("select count(*) from questions");
            rs.next();
            int count = rs.getInt(1);

            // Get random question ID from 0 to question count
            Random rand = new Random();
            int questionID = rand.nextInt(count);

            // get question with that ID
            rs = statement
                    .executeQuery("select * from questions where id = " + questionID);

            // get fields from the result
            rs.next();
            myType = rs.getString("type");
            myQuestionText = rs.getString("question");
            myAnswer = rs.getString("answer");
            // if multiple choice, get the multiple answers to display
            if (myType.equalsIgnoreCase("mc")) {
                myMcAnswers = new String[4];
                myMcAnswers[0] = rs.getString("mcAnswerA");
                myMcAnswers[1] = rs.getString("mcAnswerB");
                myMcAnswers[2] = rs.getString("mcAnswerC");
                myMcAnswers[3] = rs.getString("mcAnswerD");
            }
            // if not set the mcAnswers to null
            else {
                myMcAnswers = null;
            }
        } catch (SQLException e) {
            // if the error message is "out of memory",
            // it probably means no database file is found
            System.err.println(e.getMessage());
        }
        // Close the connection since we're done
        finally {
            try {
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                // connection close failed.
                System.err.println(e.getMessage());
            }
        }
    }

    /**
     * Get statement for question type
     *
     * @return returns the type of question
     */
    public String getType() {
        return myType;
    }

    /**
     * Gets the actual question to ask
     *
     * @return returns the question string
     */
    public String getQuestion() {
        return myQuestionText;
    }

    /**
     * Gets the CORRECT answer to the question
     *
     * @return The CORRECT answer to this specific question
     */
    public String getAnswer() {
        return myAnswer;
    }

    /**
     * Gets ALL the multiple choice answers to a mc question OR returns "This is not
     * a multiple choice question!" if the question is not multiple choice
     *
     * @return Comma separated string of the mc Answers or an alert
     */
    public String getMCAnswers() {
        String answers;
        if (this.getType().equalsIgnoreCase("mc")) {
            answers = myMcAnswers[0] + ", " + myMcAnswers[1] + ", " + myMcAnswers[2]
                    + ", " + myMcAnswers[3];
        } else {
            answers = "This is not a multiple choice question!";
        }
        return answers;
    }

    /**
     * Gets Answer A of a multiple choice question Used when creating a full
     * question String
     *
     * @return The first answer, AKA Answer A, of a mc question
     */
    private String getMCAnswerA() {
        String answers;
        if (this.getType().equalsIgnoreCase("mc")) {
            answers = myMcAnswers[0];
        } else {
            answers = "This is not a multiple choice question!";
        }
        return answers;
    }

    /**
     * Gets Answer B of a multiple choice question Used when creating a full
     * question String
     *
     * @return The second answer, AKA Answer AB of a mc question
     */
    private String getMCAnswerB() {
        String answers;
        if (this.getType().equalsIgnoreCase("mc")) {
            answers = myMcAnswers[1];
        } else {
            answers = "This is not a multiple choice question!";
        }
        return answers;
    }

    /**
     * Gets Answer C of a multiple choice question Used when creating a full
     * question String
     *
     * @return The third answer, AKA Answer C, of a mc question
     */
    private String getMCAnswerC() {
        String answers;
        if (this.getType().equalsIgnoreCase("mc")) {
            answers = myMcAnswers[2];
        } else {
            answers = "This is not a multiple choice question!";
        }
        return answers;
    }

    /**
     * Gets Answer D of a multiple choice question Used when creating a full
     * question String
     *
     * @return The fourth answer, AKA Answer D, of a mc question
     */
    private String getMCAnswerD() {
        String answers;
        if (this.getType().equalsIgnoreCase("mc")) {
            answers = myMcAnswers[3];
        } else {
            answers = "This is not a multiple choice question!";
        }
        return answers;
    }

    /**
     * Creates and returns the string representation of a Question This includes the
     * actual Question to be asked, and if true/false or multiple choice it also
     * displays the possible answers
     *
     * @return A string representation of Question object
     */
    public String toString() {
        // Add question to the string
        String result = this.getQuestion();
        // if true/false display TRUE and FALSE to prompt user
        if (this.getType().equalsIgnoreCase("tf")) {
            result = String.format("%s\n%-50s%s", result, "TRUE", "FALSE");
        }
        // if MC display possible answers
        else if (this.getType().equalsIgnoreCase("mc")) {
            result = String.format("%s\n%-50s%s\n%-50s%s", result,
                    "A: " + this.getMCAnswerA(), "B: " + this.getMCAnswerB(),
                    "C: " + this.getMCAnswerC(), "D: " + this.getMCAnswerD());
        }
        return result;
    }

    /**
     * Asks the Question and determines whether the user is correct In testing,
     * closing the Scanner would autofail later ASK tests, which is why it is not
     * clossed and the Warning is suppressed
     *
     * @return True if user correctly answers question, false otherwise
     */
    @SuppressWarnings("resource")
    public boolean askQuestion() {
        boolean isCorrect = false;
        System.out.println(this);
        Scanner input = new Scanner(System.in);
        String userAnswer = input.nextLine();
        if (userAnswer.equalsIgnoreCase(this.getAnswer())) {
            isCorrect = true;
            System.out.println(
                    "Correct!\nThe door in front of you unlatches and slowly creaks open. You proceed into the next room.\n");
        } else {
            System.out.println("Wrong! The correct answer is: " + this.getAnswer()
                    + "\nYou hear a feint click within the door in front of you, as it slowly disappears from view.\n");
        }
        return isCorrect;
    }

}
