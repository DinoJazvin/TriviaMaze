/*
 * TCSS 360
 *
 * Represents the maze that must be navigated through.
 */
package model;

import java.io.Serializable;
import java.util.Scanner;

import controller.UserInput;
import mazeSupport.Door;
import mazeSupport.Room;

/**
 * Represents the maze the user has to navigate through. Makes use of the Room
 * object for each index in the 2D array used to represent the maze.
 *
 * @author Killian Hickey
 * @author Dino Jazvin
 * @author Tylor Franklin
 *
 * @version 05/29/2021
 *
 */
public class Maze implements Serializable {

    /* Default number of doors. Do not change this value. */
    private static final int DEFAULT_DOORS = 4;

    /* Default number of rows in the 2D array. */
    private static final int DEFAULT_ROWS = 4;

    /* Default number of columns in the 2D array. */
    private static final int DEFAULT_COLUMNS = 4;

    /* Default number of rows in the 2D array. */
    private final int myRows;

    /* Default number of columns in the 2D array. */
    private final int myColumns;

    /* The current row the player is in. */
    private int myCurrentRow;

    /* The current column the player is in. */
    private int myCurrentCol;

    /* Tracks which room the player is currently in. */
    private Room myCurrentRoom;

    /* A 2D array of rooms representing the maze. */
    protected final Room[][] myMaze;

    /**
     * Default constructor which assigns the maze array to be a four by four array.
     * Initializes each index of the 2D Room array with a new Room. It then
     * initializes an array of 4 doors in each Room.
     */
    public Maze() {
        myRows = DEFAULT_ROWS;
        myColumns = DEFAULT_COLUMNS;
        myMaze = new Room[DEFAULT_ROWS][DEFAULT_COLUMNS];
        myCurrentRow = 0;
        myCurrentCol = 0;
        for (int i = 0; i < myRows; i++) {
            for (int j = 0; j < myColumns; j++) {
                Door[] setDoors = new Door[DEFAULT_DOORS];
                for (int k = 0; k < DEFAULT_DOORS; k++) {
                    setDoors[k] = new Door();
                }
                myMaze[i][j] = new Room(setDoors);
            }
        }
        myMaze[myCurrentRow][myCurrentCol].setPlayer(true);
        myCurrentRoom = myMaze[myCurrentRow][myCurrentCol];
        setDoorBorderStatus();
    }

    /**
     * Overloaded constructor which assigns the maze array to be a X by Y array
     * where the dimensions of the maze are determined by the user. Initializes each
     * index of the 2D Room array with a new Room. It then initializes an array of 4
     * doors in each Room.
     *
     * @param theRows    Number of rows chosen for the maze.
     * @param theColumns Number of columns chosen for the maze.
     */
    public Maze(final int theRows, final int theColumns) {
        myRows = theRows;
        myColumns = theColumns;
        myMaze = new Room[theRows][theColumns];
        myCurrentRow = 0;
        myCurrentCol = 0;
        for (int i = 0; i < myRows; i++) {
            for (int j = 0; j < myColumns; j++) {
                Door[] setDoors = new Door[DEFAULT_DOORS];
                for (int k = 0; k < DEFAULT_DOORS; k++) {
                    setDoors[k] = new Door();
                }
                myMaze[i][j] = new Room(setDoors);
            }
        }
        myMaze[myCurrentRow][myCurrentCol].setPlayer(true);
        myCurrentRoom = myMaze[myCurrentRow][myCurrentCol];
        setDoorBorderStatus();
    }

    /**
     * Sets the exists status of doors around the border of the maze to false. The
     * player will not be able to interact with these doors.
     */
    private void setDoorBorderStatus() {
        for (int i = 0; i < myRows; i++) {
            for (int j = 0; j < myColumns; j++) {
                if (i == 0) {
                    myMaze[i][j].getDoorNorth().setExists(false);
                }
                if (j == 0) {
                    myMaze[i][j].getDoorWest().setExists(false);
                }
                if (j == myColumns - 1) {
                    myMaze[i][j].getDoorEast().setExists(false);
                }
                if (i == myRows - 1) {
                    myMaze[i][j].getDoorSouth().setExists(false);
                }
            }
        }
    }

    /**
     * Checks to see whether the door has been interacted with. If it has, the user
     * passes to the specified index of the maze. If it has not been interacted with
     * the user is prompted with a question. If they get the question right they
     * move to the next index.
     *
     * @param theDirection direction in which to move
     */
    public void checkDoor(char theDirection) {
        if(theDirection == '1')
            return;
        if (theDirection == '2')
            return;
        boolean actualMove = false;
        int doorIndex = convertToIndex(theDirection);
        // Get door
        Door currentDoor = myCurrentRoom.getDoor(doorIndex);
        // If door is locked it has not been interacted with yet
        if (currentDoor.getLockStatus() == false) {
            currentDoor.tryDoor();
        }
        // if door exists move is valid
        if (currentDoor.getExistsStatus()) {
            actualMove = true;
        }
        if (actualMove) {
            setPlayerRoom(theDirection);
        }
    }

    /**
     * Sets the boundary of the maze for the player by checking to see if there is a
     * door in front of them and returning true if there is. If there is the players
     * position is changed to their target position. If not, returns false.
     *
     * @param theDirection The direction the player is trying to go.
     * @return Returns whether there is a door in front of the player.
     */
    public boolean getCurrentDoor(char theDirection) {
        boolean isDoor = false;
        if (theDirection == 'w' && myCurrentRoom.isDoorNorth()) {
            isDoor = true;
        }
        if (theDirection == 'a' && myCurrentRoom.isDoorWest()) {
            isDoor = true;
        }
        if (theDirection == 's' && myCurrentRoom.isDoorSouth()) {
            isDoor = true;
        }
        if (theDirection == 'd' && myCurrentRoom.isDoorEast()) {
            isDoor = true;
        }
        return isDoor;
    }

    /**
     * Increments the players location in the maze. Sets their new location to true,
     * and sets the room they were previously in to false.
     */
    private void setPlayerRoom(char theDirection) {
        myCurrentRoom.setPlayer(false);
        if (theDirection == 'w') {
            myCurrentRow -= 1;
            myMaze[myCurrentRow][myCurrentCol].setPlayer(true);
            myCurrentRoom = myMaze[myCurrentRow][myCurrentCol];
        }
        if (theDirection == 'a') {
            myCurrentCol -= 1;
            myMaze[myCurrentRow][myCurrentCol].setPlayer(true);
            myCurrentRoom = myMaze[myCurrentRow][myCurrentCol];
        }
        if (theDirection == 's') {
            myCurrentRow += 1;
            myMaze[myCurrentRow][myCurrentCol].setPlayer(true);
            myCurrentRoom = myMaze[myCurrentRow][myCurrentCol];
        }
        if (theDirection == 'd') {
            myCurrentCol += 1;
            myMaze[myCurrentRow][myCurrentCol].setPlayer(true);
            myCurrentRoom = myMaze[myCurrentRow][myCurrentCol];
        }
    }

    /**
     *
     */
    public Room getRoom(final int theRow, final int theCol) {
        return myMaze[theRow][theCol];
    }

    /**
     * Returns the height of the columns in the maze.
     *
     * @return The height of the maze.
     */
    public int getMazeHeight() {
        return myRows;
    }

    /**
     * Returns the height of the columns in the maze.
     *
     * @return The width of the maze.
     */
    public int getMazeWidth() {
        return myColumns;
    }

    public int getCurrentRow() {
        return myCurrentRow;
    }

    public int getCurrentCol() {
        return myCurrentCol;
    }

    /**
     * Changes a direction to a door index to grab a door from a room
     *
     * @param theDirection Character representing user attempted movement
     * @return Int index of the door the player used
     */
    private int convertToIndex(char theDirection) {
        int index = -1;
        if (theDirection == 'w') {
            index = 0;
        } else if (theDirection == 'a') {
            index = 3;
        } else if (theDirection == 's') {
            index = 2;
        } else if (theDirection == 'd') {
            index = 1;
        }
        return index;
    }

    /**
     * Returns a boolean representing whether the player has reached the end of the
     * maze.
     *
     * @return Whether the player is in last index of the maze.
     */
    public boolean winCondition() {
        boolean win = true;
        if (myMaze[myRows - 1][myColumns - 1].getPlayer()) {
            win = false;
        }
        return win;
    }

    /**
     * This method checks to see whether the current maze can still be completed. It
     * checks each room in the maze, if it is able to make it to the final room the
     * method will return true. If it is not, it will return false.
     *
     * @param theRow    The current row being checked.
     * @param theColumn The current column being checked.
     * @return Whether the maze is still solvable.
     */
    public boolean solvableMaze(int theRow, int theColumn) {
        boolean solvable = false;
        myMaze[theRow][theColumn].setVisit(true);
        if (theRow == myRows - 1 && theColumn == myColumns - 1) {
            solvableHelper();
            return true;
        }
        if (myMaze[theRow][theColumn].getDoorEast().getExistsStatus() == true
                && myMaze[theRow][theColumn + 1].getVisit() == false
                && solvable != true) {
            solvable = solvableMaze(theRow, theColumn + 1);
        }
        if (myMaze[theRow][theColumn].getDoorNorth().getExistsStatus() == true
                && myMaze[theRow - 1][theColumn].getVisit() == false
                && solvable != true) {
            solvable = solvableMaze(theRow - 1, theColumn);
        }
        if (myMaze[theRow][theColumn].getDoorSouth().getExistsStatus() == true
                && myMaze[theRow + 1][theColumn].getVisit() == false
                && solvable != true) {
            solvable = solvableMaze(theRow + 1, theColumn);
        }
        if (myMaze[theRow][theColumn].getDoorWest().getExistsStatus() == true
                && myMaze[theRow][theColumn - 1].getVisit() == false
                && solvable != true) {
            solvable = solvableMaze(theRow, theColumn - 1);
        }
        return solvable;
    }

    /**
     * This method helps check to see whether the maze is still solvable. After the
     * maze has been checked for whether it is solvable this method will go through
     * and reset the visited flags.
     */
    public void solvableHelper() {
        for (int i = 0; i < myRows; i++) {
            for (int j = 0; j < myColumns; j++) {
                myMaze[i][j].setVisit(false);
            }
        }
    }

    /**
     * Provides a string representation of the players current position in the maze.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("You are in room (" + (myCurrentRow + 1) + ", " + (myCurrentCol + 1)
                + ")");
        sb.append(" Out of: (" + myRows + ", " + myColumns + ")\n");
        sb.append(myCurrentRoom.toString() + "\n");
        return sb.toString();
    }

    /**
     * Method which calls convertToIndex for testing purposes.
     *
     * @param theDirection Direction the user wants to go.
     * @return Returns an index relating to the direction.
     */
    public int callConvert(char theDirection) {
        return convertToIndex(theDirection);
    }

    /**
     * Method which calls setPlayerRoom for testing purposes.
     *
     * @param theDirection The direction the user wants to go.
     */
    public void testPlayerRoom(char theDirection) {
        setPlayerRoom(theDirection);
    }
}
