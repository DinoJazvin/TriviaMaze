package sql;

import java.io.Serializable;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
// SQL reserved words are not case sensitive.
public class SqlConnection implements Serializable {

    public static void main(String[] theArgs) {
        Connection connect = null;
        try {
            connect = DriverManager.getConnection(/*jdbc:sqlite:*/ /*database name here */ /*.db*/null);
            // Create statement to issue commands to database
            Statement command = connect.createStatement();
            command.setQueryTimeout(20);
            // Allows us to provide a SQL command to our database. Changes database in some way.
            // This statement checks to see if there is a table called person.
            command.executeUpdate("drop table if exists person.");
            // This creates a table out of a person with an id and name.
            command.executeUpdate("create table person(id integer, name string");
            // Query allows us to look at contents of database without modifying it.
            ResultSet rs = command.executeQuery("Select *");
            // This will grab data from the current line
            while (rs.next()) {

            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                if (connect != null) {
                    connect.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }
}
