/*
 * TCSS 360
 *
 * Represents the room of a maze.
 */
package mazeSupport;

import java.io.Serializable;

/**
 * Represents a Room in a maze. Each room has at least one door, a wall, and
 * possibly a player within it.
 *
 * @author Killian Hickey
 * @author Tylor Franklin
 * @author Dino Jazvin
 *
 * @version 05/13/2021
 *
 */
public class Room implements Serializable {

    /* Default number of doors. Do not change this value. */
    private static final int DEFAULT_NUM_DOORS = 4;

    /* An array of four doors for each room of the maze. */
    private Door[] myDoor = new Door[DEFAULT_NUM_DOORS];

    /* Represents whether the player is in this room. */
    private boolean myPlayer;

    /* Represents whether the room has been visited. */
    private boolean myVisit;

    /**
     * Default constructor of a room.
     */
    public Room() {

    }

    /**
     * Overloaded constructor allowing someone to define their own player, wall, and
     * doors.
     *
     * @param theDoor
     * @param theWall
     * @param thePlayer
     */
    public Room(Door[] theDoor) {
        myDoor = theDoor;
        myPlayer = false;
        myVisit = false;
    }

    /**
     * Returns a reference to a door specified by the index provided.
     *
     * @param index Targets the door to access.
     * @return
     */
    public Door getDoor(int theIndex) {
        return myDoor[theIndex];
    }

    /**
     * Returns the player field.
     *
     * @return Returns the play object.
     */
    public boolean getPlayer() {
        return myPlayer;
    }

    /**
     * Sets whether the current room has been visited by the player.
     *
     * @param theVisit The visit status of the player.
     */
    public void setVisit(boolean theVisit) {
        myVisit = theVisit;
    }

    /**
     * Returns whether the room has been visited.
     *
     * @return Whether the room has been visited or not.
     */
    public boolean getVisit() {
        return myVisit;
    }

    /**
     * Sets the player field to boolean value specified
     *
     * @param theNewRoom
     */
    public void setPlayer(boolean theNewRoom) {
        myPlayer = theNewRoom;
    }

    /**
     * Checks to see whether the door above the player in the 2D array can be
     * interacted with.
     *
     * @return Returns a boolean of whether the door exists.
     */
    public boolean isDoorNorth() {
        return myDoor[0].getExistsStatus();
    }

    /**
     * Checks to see whether the door to the right of the player in the 2D array can
     * be interacted with.
     *
     * @return Returns a boolean of whether the door exists.
     */
    public boolean isDoorEast() {
        return myDoor[1].getExistsStatus();
    }

    /**
     * Checks to see whether the door below the player in the 2D array can be
     * interacted with.
     *
     * @return Returns a boolean of whether the door exists.
     */
    public boolean isDoorSouth() {
        return myDoor[2].getExistsStatus();
    }

    /**
     * Checks to see whether the door to the left of the player in the 2D array can
     * be interacted with.
     *
     * @return Returns a boolean of whether the door exists.
     */
    public boolean isDoorWest() {
        return myDoor[3].getExistsStatus();
    }

    /**
     * Returns the door in the Northern part of the room.
     *
     * @return The door to the North.
     */
    public Door getDoorNorth() {
        if (myDoor[0] != null) {
            return myDoor[0];
        } else {
            throw new NullPointerException("This door does not exist.");
        }
    }

    /**
     * Returns the door in the Eastern part of the room.
     *
     * @return The door to the East.
     */
    public Door getDoorEast() {
        if (myDoor[1] != null) {
            return myDoor[1];
        } else {
            throw new NullPointerException("This door does not exist.");
        }
    }

    /**
     * Returns the door in the Southern part of the room.
     *
     * @return The door to the South.
     */
    public Door getDoorSouth() {
        if (myDoor[2] != null) {
            return myDoor[2];
        } else {
            throw new NullPointerException("This door does not exist.");
        }
    }

    /**
     * Returns the door in the Western part of the room.
     *
     * @return The door to the West.
     */
    public Door getDoorWest() {
        if (myDoor[3] != null) {
            return myDoor[3];
        } else {
            throw new NullPointerException("This door does not exist.");
        }
    }

    /**
     * Overrides the default toString. Prints out whether each of the four doors in
     * each room the player enters exist.
     */
    @Override
    public String toString() {
        StringBuilder strb = new StringBuilder("");
        if (isDoorNorth())
            strb.append("There is a door to your North\n");
        if (isDoorEast())
            strb.append("There is a door to your East\n");
        if (isDoorSouth())
            strb.append("There is a door to your South\n");
        if (isDoorWest())
            strb.append("There is a door to your West\n");

        return strb.toString();
    }

}
