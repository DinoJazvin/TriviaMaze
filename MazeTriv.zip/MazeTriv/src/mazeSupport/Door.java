/*
 * TCSS 360
 *
 * This class represents a door in a maze.
 */
package mazeSupport;
import model.Question;

import java.io.Serializable;

/**
 * This represents a door in one of the rooms of the maze. Has a trivia question
 * assigned to it and will be interacted with by the player.
 *
 * @author Killian Hickey
 * @author Tylor Franklin
 * @author Dino Jazvin
 *
 * @version 05/29/2021
 *
 */
public final class Door extends Room implements Serializable {

    /*Doors default LOCKED, Unlock if question is right*/
    private static final boolean DEFAULT_LOCK = false;

    /*Doors exist by default, are erased from existence if answer is wrong*/
    private static final boolean DEFAULT_EXISTENCE = true;

    /* Controls whether the door is locked or not. */
    private boolean myLock;

    /* Controls whether the door can be interacted with. */
    private boolean myExistence;

    /*Question to ask if door is interacted with*/
    private Question myQuestion;

    /**
     * Constructor for the doors which sets its locked status to true, and its
     * existence status to true.
     */
    public Door() {
        myExistence = DEFAULT_EXISTENCE;
        myLock = DEFAULT_LOCK;
        myQuestion = new Question();
    }

    /**
     * Sets whether the door will be locked or not, based on input.
     *
     * @param theNewLock Boolean representation of answer to the trivia question.
     */
    public void setLock(final boolean theNewLock) {
        myLock = theNewLock;
    }

    /**
     * Sets whether the door can be interacted with, based on input.
     *
     * @param theNewExists Boolean representation of answer to the trivia question.
     */
    public void setExists(final boolean theNewExists) {
        myExistence = theNewExists;
    }

    /**
     * Returns whether the door is locked or unlocked.
     *
     * @return Status of the lock.
     */
    public boolean getLockStatus() {
        return myLock;
    }

    /**
     * Returns whether the door exists.
     *
     * @return Status of the doors existence.
     */
    public boolean getExistsStatus() {
        return myExistence;
    }

    /**
     * When door is interacted with, ask question
     * Send whether the question was answered correctly
     * to function to change door status.
     */
    public void tryDoor()
    {
        this.receiveAnswer(myQuestion.askQuestion());
    }

    /**
     * Changes door status based on answer to question.
     * If answer is correct - Door unlocks, and continues to exist
     * If answer is wrong - Door stays locked, and is erased from existence
     * @param theAnswer is TRUE is a question is answered correctly.
     */
    public void receiveAnswer(final boolean theAnswer) {
        myLock = theAnswer;
        myExistence = theAnswer;
    }

}
