package tests;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Before;
import org.junit.Test;

import controller.UserInput;
import model.Maze;

public class UserInputTests {

    private static Scanner console = new Scanner(System.in);

    @Test
    public void testMazeSize() {
        System.out.println("Enter these numbers in order: 3, 7, 4, 5, 6.");
        assertEquals("This should return 4.", UserInput.mazeSize(console), 4);
        assertEquals("This should return 5.", UserInput.mazeSize(console), 5);
        assertEquals("This should return 6.", UserInput.mazeSize(console), 6);
    }

    @Test
    public void testGetMoveAllowed() {
        Maze test = new Maze();
        System.out.println("Enter these directions in order: e, s, d, a, w");
        test.testPlayerRoom('s');
        test.testPlayerRoom('d');
        assertEquals("This should return s", UserInput.getMove(console, test), 's');
        assertEquals("This should return d", UserInput.getMove(console, test), 'd');
        assertEquals("This should return a", UserInput.getMove(console, test), 'a');
        assertEquals("This should return w", UserInput.getMove(console, test), 'w');
    }

    @Test
    public void testGetMoveNotAllow() {
        Maze test = new Maze();
        System.out.println("Enter these two characters: w then d");
        assertEquals("This should return d", UserInput.getMove(console, test), 'd');
    }

    @Test
    public void testPromptPlayAgainYes() {
        System.out.println("Enter something other than y or n, then enter y");
        assertTrue("This should be true when they enter y!",
                UserInput.promptPlayAgain(console));
    }

    @Test
    public void testPromptPlayAgainNo() {
        System.out.println("Enter n");
        assertFalse("This should be false when they enter n!",
                UserInput.promptPlayAgain(console));
    }

}
