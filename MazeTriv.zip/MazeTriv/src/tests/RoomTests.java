package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import mazeSupport.Room;
import model.Maze;

public class RoomTests {

    @Test
    public void testGetDoor() {
        Maze test = new Maze();
        assertEquals("These doors should be the same!", test.getRoom(0, 0).getDoorNorth(),
                test.getRoom(0, 0).getDoor(0));
    }

    @Test
    public void testGetPlayerTrue() {
        Maze test = new Maze();
        assertTrue("The player should be in the starting room!", test.getRoom(0, 0).getPlayer());
    }

    @Test
    public void testGetPlayerFalse() {
        Maze test = new Maze();
        assertFalse("THe player should be in the starting room!", test.getRoom(0, 1).getPlayer());
    }

    @Test
    public void testSetVisitTrue() {
        Room test = new Room();
        test.setVisit(true);
        assertTrue("the visit status should be true!", test.getVisit());
    }

    @Test
    public void testSetVisitFalse() {
        Room test = new Room();
        test.setVisit(false);
        assertFalse("the visit status should be false!", test.getVisit());
    }

    @Test
    public void testDoorNorth() {
        Maze test = new Maze();
        assertFalse("The Northern door should not exist!", test.getRoom(0, 0).isDoorNorth());
    }

    @Test
    public void testDoorEast() {
        Maze test = new Maze();
        assertTrue("The Eastern door should exist!", test.getRoom(0, 0).isDoorEast());
    }

    @Test
    public void testDoorSouth() {
        Maze test = new Maze();
        assertTrue("The Southern door should exist!", test.getRoom(0, 0).isDoorSouth());
    }

    @Test
    public void testDoorWest() {
        Maze test = new Maze();
        assertFalse("The Western door should not exist!", test.getRoom(0, 0).isDoorWest());
    }

    @Test
    public void testToString() {
        Maze test = new Maze();
        test.testPlayerRoom('s');
        test.testPlayerRoom('d');
        assertEquals("The strings should be equal!", test.toString(),
                "You are in room (2, 2) Out of: (4, 4)\nThere is a door to " + "your North\n" + "There is a door to your East"
                        + "\nThere is a door to your South\n" + "There is a door to your West\n\n");
    }

    @Test (expected = NullPointerException.class)
    public void testDoorDirectionNorthNull() {
        Room test = new Room();
        test.getDoorNorth();
    }

    @Test (expected = NullPointerException.class)
    public void testDoorDirectionEastNull() {
        Room test = new Room();
        test.getDoorEast();
    }

    @Test (expected = NullPointerException.class)
    public void testDoorDirectionSouthNull() {
        Room test = new Room();
        test.getDoorSouth();
    }

    @Test (expected = NullPointerException.class)
    public void testDoorDirectionWestNull() {
        Room test = new Room();
        test.getDoorWest();
    }

    @Test
    public void testDoorDirectionNotNull() {
        Maze test = new Maze();
        test.testPlayerRoom('s');
        test.testPlayerRoom('d');
        assertEquals("These doors should be the same!", test.getRoom(0, 0).getDoorNorth(),
                test.getRoom(0, 0).getDoor(0));
        assertEquals("These doors should be the same!", test.getRoom(0, 0).getDoorEast(),
                test.getRoom(0, 0).getDoor(1));
        assertEquals("These doors should be the same!", test.getRoom(0, 0).getDoorSouth(),
                test.getRoom(0, 0).getDoor(2));
        assertEquals("These doors should be the same!", test.getRoom(0, 0).getDoorWest(),
                test.getRoom(0, 0).getDoor(3));
    }

}
