package tests;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;

import mazeSupport.Door;

public class DoorTests {

    @Test
    public void getLockTest() {
        Door door = new Door();
        assertTrue(!door.getLockStatus());
    }

    @Test
    public void setLockTest() {
        Door door = new Door();
        door.setLock(true);
        assertTrue(door.getLockStatus());
    }

    @Test
    public void getExistenceTest() {
        Door door = new Door();
        assertTrue(door.getExistsStatus());
    }

    @Test
    public void setExistenceTest() {
        Door door = new Door();
        door.setExists(false);
        assertTrue(!door.getExistsStatus());
    }

    @Test
    public void useCorrectAnswerTest() {
        Door door = new Door();
        door.receiveAnswer(true);
        assertTrue(door.getLockStatus() && door.getExistsStatus());
    }

    @Test
    public void useIncorrectAnswerTest() {
        Door door = new Door();
        door.receiveAnswer(false);
        assertTrue(!door.getLockStatus() && !door.getExistsStatus());
    }

    @Test
    public void tryDoorPassTest() {
        Door door = new Door();
        System.out.println("Get question right");
        door.tryDoor();
        assertTrue(door.getLockStatus());
    }

    @Test
    public void tryDoorFailTest() {
        Door door = new Door();
        System.out.println("Get question wrong");
        door.tryDoor();
        assertTrue(!door.getExistsStatus());
    }

}
