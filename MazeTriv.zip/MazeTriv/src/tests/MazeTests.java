package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import model.Maze;

public class MazeTests {

    @Test
    public void testWinConditionTrue() {
        Maze testMaze = new Maze();
        assertTrue("The win condition should not be completed!", testMaze.winCondition());
    }

    @Test
    public void testWinConditionFalse() {
        Maze testMaze = new Maze();
        testMaze.getRoom(testMaze.getMazeHeight() - 1, testMaze.getMazeWidth() - 1)
                .setPlayer(true);
        assertFalse("The win condition should be completed!", testMaze.winCondition());
    }

    @Test
    public void testMazeWidth() {
        Maze testMaze = new Maze();
        assertEquals("The width of the maze is wrong!", testMaze.getMazeWidth(), 4);
    }

    @Test
    public void testMazeHeight() {
        Maze testMaze = new Maze();
        assertEquals("The height of the maze is wrong!", testMaze.getMazeHeight(), 4);
    }

    @Test
    public void testCurrentRow() {
        Maze testMaze = new Maze();
        assertEquals("Retrieved the wrong row!", testMaze.getCurrentRow(), 0);
    }

    @Test
    public void testMCurrentCol() {
        Maze testMaze = new Maze();
        assertEquals("Retrieved the wrong column!", testMaze.getCurrentCol(), 0);
    }

    @Test
    public void testPrintMaze() {
        Maze testMaze = new Maze();
        String test = testMaze.toString();
        assertEquals("The strings are not equal!", test,
                "You are in room (1, 1) Out of: (4, 4)\n"
                        + "There is a door to your East\n"
                        + "There is a door to your South\n\n" + "");
    }

    @Test
    public void testCheckDoorLocked() {
        Maze testMaze = new Maze();
        testMaze.getRoom(0, 0).getDoorNorth().setLock(true);
        testMaze.checkDoor('w');
        assertTrue("The player should be at the starting row!",
                testMaze.getCurrentRow() == 0);
        assertTrue("The player should be at the starting column!",
                testMaze.getCurrentCol() == 0);

    }

    @Test
    public void testCheckDoorUnlocked() {
        Maze testMaze = new Maze();
        testMaze.checkDoor('s');
        assertTrue("The player should move to the South!", testMaze.getCurrentRow() == 1);
        assertTrue("The player should move to the South!", testMaze.getCurrentCol() == 0);

    }

    @Test
    public void testSetDoorBorderStatusFalse() {
        Maze testMaze = new Maze();
        for (int i = 0; i < testMaze.getMazeHeight(); i++) {
            assertFalse("Door exists when it shouldn't!",
                    testMaze.getRoom(i, 0).getDoor(3).getExistsStatus());
        }
        for (int j = 0; j < testMaze.getMazeWidth(); j++) {
            assertFalse("Door exists when it shouldn't!",
                    testMaze.getRoom(0, j).getDoor(0).getExistsStatus());
        }
        for (int i = 0; i < testMaze.getMazeHeight(); i++) {
            assertFalse("Door exists when it shouldn't!",
                    testMaze.getRoom(i, testMaze.getMazeWidth() - 1).getDoor(1)
                            .getExistsStatus());
        }
        for (int j = 0; j < testMaze.getMazeWidth(); j++) {
            assertFalse("Door exists when it shouldn't!",
                    testMaze.getRoom(testMaze.getMazeHeight() - 1, j).getDoor(2)
                            .getExistsStatus());
        }
    }

    @Test
    public void testSolvableMazeCan() {
        Maze test = new Maze(5, 5);
        for (int i = 0; i < test.getMazeHeight(); i++) {
            for (int j = 0; j < test.getMazeWidth(); j++) {
                assertTrue("The maze should be solvable from any position in the maze!",
                        test.solvableMaze(i, j));
            }
        }
    }

    @Test
    public void testSolvableMazeCannot() {
        Maze test = new Maze();
        test.getRoom(0, 0).getDoorEast().setExists(false);
        test.getRoom(0, 0).getDoorSouth().setExists(false);
        assertFalse("The maze should not be solvable", test.solvableMaze(0, 0));
    }

    @Test
    public void testConverToIndex() {
        Maze test = new Maze();
        assertEquals("Value returned should be 1!", test.callConvert('w'), 0);
        assertEquals("Value returned should be 1!", test.callConvert('a'), 3);
        assertEquals("Value returned should be 1!", test.callConvert('s'), 2);
        assertEquals("Value returned should be 1!", test.callConvert('d'), 1);
    }

    @Test
    public void testCurrentDoor() {
        Maze test = new Maze();
        test.testPlayerRoom('d');
        test.testPlayerRoom('s');
        assertTrue("This door should not exist!", test.getCurrentDoor('w'));
        assertTrue("This door should not exist!", test.getCurrentDoor('a'));
        assertTrue("This door should exist!", test.getCurrentDoor('s'));
        assertTrue("This door should exist!", test.getCurrentDoor('d'));
    }

    @Test
    public void SetPlayerRoom() {
        Maze test = new Maze();
        test.testPlayerRoom('d');
        assertEquals("The player should have moved right!", test.getCurrentCol(), 1);
        test.testPlayerRoom('s');
        assertEquals("The player should have moved down!", test.getCurrentRow(), 1);
        test.testPlayerRoom('a');
        assertEquals("The player should have moved left!", test.getCurrentCol(), 0);
        test.testPlayerRoom('w');
        assertEquals("The player should have moved up!", test.getCurrentCol(), 0);
    }

}
