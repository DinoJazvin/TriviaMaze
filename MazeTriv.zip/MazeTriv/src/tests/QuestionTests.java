package tests;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;

import model.Question;

public class QuestionTests {

    @Test
    public void questionCreationTest() {
        Question question = new Question();
        assertNotNull(question);
    }

    @Test
    public void questionCreationTimeTest() {
        long startTime = System.nanoTime();
        Question question = new Question();
        long endTime = System.nanoTime();
        long duration = (endTime - startTime) / 1000000;
        System.out.println("Time to create 1 question in milliseconds:" + duration);
        assertTrue(duration <= 1000);
    }

    @Test
    public void averageTimeTest100() {
        long total = 0;
        for (int i = 0; i < 100; i++) {
            long startTime = System.nanoTime();
            Question question = new Question();
            long endTime = System.nanoTime();
            long duration = (endTime - startTime) / 1000000;
            total += duration;
        }
        System.out.println("Total time for 100 questions in milliseconds: " + total);
        total = total / 100;
        System.out.println("Average time for 100 questions in milliseconds: " + total);
        assertTrue(total <= 1000);
    }

    @Test
    public void averageTimeTest1000() {
        long total = 0;
        for (int i = 0; i < 1000; i++) {
            long startTime = System.nanoTime();
            Question question = new Question();
            long endTime = System.nanoTime();
            long duration = (endTime - startTime) / 1000000;
            total += duration;
        }
        System.out.println("Total time for 1000 questions in milliseconds: " + total);
        total = total / 1000;
        System.out.println("Average time for 1000 questions in milliseconds: " + total);
        assertTrue(total <= 1000);
    }

    @Test
    public void getShortRightTest() {
        System.out.println("");
        Question question = new Question();
        while (!question.getType().equalsIgnoreCase("short")) {
            question = new Question();
        }
        System.out.println("Type correct Answer: " + question.getAnswer());
        assertTrue(question.askQuestion());
    }

    @Test
    public void getTFRightTest() {
        System.out.println("");
        Question question = new Question();
        while (!question.getType().equalsIgnoreCase("tf")) {
            question = new Question();
        }
        System.out.println("Type correct Answer: " + question.getAnswer());
        assertTrue(question.askQuestion());
    }

    @Test
    public void getMCRightTest() {
        System.out.println("");
        Question question = new Question();
        while (!question.getType().equalsIgnoreCase("mc")) {
            question = new Question();
        }
        System.out.println("Type correct Answer: " + question.getAnswer());
        assertTrue(question.askQuestion());
    }

    @Test
    public void getShortWrongTest() {
        System.out.println("");
        Question question = new Question();
        while (!question.getType().equalsIgnoreCase("short")) {
            question = new Question();
        }
        System.out.println("Don't type this: " + question.getAnswer());
        assertTrue(!question.askQuestion());
    }

    @Test
    public void getTFWrongTest() {
        System.out.println("");
        Question question = new Question();
        while (!question.getType().equalsIgnoreCase("tf")) {
            question = new Question();
        }
        System.out.println("Don't type this: " + question.getAnswer());
        assertTrue(!question.askQuestion());
    }

    @Test
    public void getMCWrongTest() {
        System.out.println("");
        Question question = new Question();
        while (!question.getType().equalsIgnoreCase("mc")) {
            question = new Question();
        }
        System.out.println("Don't type this: " + question.getAnswer());
        assertTrue(!question.askQuestion());
    }

}
