////
//// Source code recreated from a .class file by IntelliJ IDEA
//// (powered by FernFlower decompiler)
////
//
//package controller;
//
//import java.io.*;
//import java.util.Scanner;
//import model.Maze;
//
//public class Main implements Serializable {
//    public Main() {
//    }
//
//    public static void main(String[] args) {
//        Scanner console = new Scanner(System.in);
//        boolean wantsToPlay = true;
//        UserInput.printIntroduction();
//
//        for(boolean var3 = true; wantsToPlay; wantsToPlay = UserInput.promptPlayAgain(console)) {
//            int mazeSize = UserInput.mazeSize(console);
//            Maze test = new Maze(mazeSize, mazeSize);
//            boolean didWin = true;
//
//            boolean solvable;
//            for(solvable = true; didWin && solvable; solvable = test.solvableMaze(test.getCurrentRow(), test.getCurrentCol())) {
//                test.printCurrentRoom();
//                test.checkDoor(UserInput.getMove(console, test));
//                didWin = test.winCondition();
//            }
//
//            if (!didWin) {
//                UserInput.printWinMessage();
//            } else if (!solvable) {
//                UserInput.lossMessage();
//            }
//
////            //Serializing Maze Object
////            String fileName = "file.ser";
////            Serialize(test, fileName);
////
////            //Deserializing Maze Object
////            Maze test1 = Deserialize(fileName);
//        }
//
//    }
//
//    public static void Serialize(Maze test, String fileName){
//
//        try {
//            //Saving of object in a file
//            FileOutputStream file = new FileOutputStream(fileName);
//            ObjectOutputStream out = new ObjectOutputStream(file);
//
//            // Method for serialization of object
//            out.writeObject(test);
//
//            out.close();
//            file.close();
//
//            System.out.println("Object has been serialized");
//
//        }
//
//        catch(IOException ex) {
//            System.out.println("IOException is caught");
//        }
//    }
//
//    public static Maze Deserialize(String fileName) {
//
//        Maze test1 = null;
//
//        // Deserialization
//        try {
//            // Reading the object from a file
//            FileInputStream file = new FileInputStream(fileName);
//            ObjectInputStream in = new ObjectInputStream(file);
//
//            //Casting object as Maze
//            test1 = (Maze) in.readObject();
//
//            in.close();
//            file.close();
//
//            System.out.println("Object has been deserialized ");
//        }
//
//        catch(IOException ex) {
//            System.out.println("IOException is caught");
//        }
//
//        catch(ClassNotFoundException ex) {
//            System.out.println("ClassNotFoundException is caught");
//        }
//        return test1;
//    }
//}
