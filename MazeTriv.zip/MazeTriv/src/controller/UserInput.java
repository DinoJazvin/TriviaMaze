package controller;

/*
 * TCSS 360
 *
 * Handles user input and messages.
 */
import java.io.Serializable;
import java.util.Scanner;

import model.Maze;

/**
 * This class handles all input from the user, and passes it back to main for
 * use in the maze. It also handles printing information relevant to the user.
 *
 * @author Killian Hickey
 * @author Dino Jazvin
 * @author Tylor Franklin
 *
 * @version 06/01/2021
 *
 */
public class UserInput implements Serializable {

    private static boolean save;
    private static boolean load;

    /**
     * Prints an introduction to the maze for the user.
     */
    public static void printIntroduction() {
        System.out
                .println("Welcome to the Trivia Maze. You will have the opportunity to");
        System.out.println(
                "navigate through a matrix, trying to get to the bottom right-most");
        System.out.println(
                "corner. Along the way you will encounter doors where you will be prompted");
        System.out.println(
                "to answer Video-Game trivia. Get too many questions wrong and you will lose.");
        System.out.println("Good luck!\n\n");
    }

    /**
     * This prompts the user to enter a size for the maze. IUf their input is not
     * within the specified range they will be prompted again.
     *
     * @param theConsole Scanner used for user input.
     * @return Returns the size of the maze.
     */
    public static int mazeSize(Scanner theConsole) {
        String prompt = "What number of rows and columns would you like in the maze? "
                + "(Please enter a number in the range 4-6): ";
        String incInt = "\nYour input is not an integer in the range 4-6, please try again. ";
        int mazeSize = mazeSizeHelper(theConsole, incInt, prompt);
        while (mazeSize < 4 || mazeSize > 6) {
            System.out.print(incInt);
            mazeSize = mazeSizeHelper(theConsole, incInt, prompt);
        }
        return mazeSize;
    }

    /**
     * This method helps get correct input for the size of the maze. If the user
     * enters something other than an integer, this method will prompt them for the
     * correct input.
     *
     * @param theConsole Scanner used for user input.
     * @param theIncInt  String telling the user they entered something wrong.
     * @param thePrompt  String prompting the user to enter something.
     * @return Returns an integer.
     */
    private static int mazeSizeHelper(Scanner theConsole, String theIncInt,
                                      String thePrompt) {
        System.out.print(thePrompt);
        while (!theConsole.hasNextInt()) {
            theConsole.next();
            System.out.print(theIncInt + thePrompt);
        }
        return theConsole.nextInt();
    }

    /**
     * This method prompts the user for which direction they would like to go in the
     * maze. If the user enters something other than the specified accepted input,
     * or if the direction they chose to move does not have a door, they will be
     * re-prompted until they enter in correct input.
     *
     * @param theConsole Scanner used for user input.
     * @param theMaze    The maze the user is attempting to navigate through.
     * @return Returns the direction the user has chosen to go.
     */
    public static char getMove(Scanner theConsole, Maze theMaze) {
        displayMenu();
        String prompt = "Which direction would you like to go?\n"
                + "(Please use W for North, D for East, S for South, and A for West.): ";
        System.out.print(prompt);
        String room = theMaze.toString();
        char direction = 'l';
        direction = theConsole.next().charAt(0);
        // Check for valid direction
        while (direction != 'w' && direction != 'a' && direction != 's'
                && direction != 'd' && direction != '1' && direction != '2') {
            System.out.println("Sorry, your input wasn't recognized. " + prompt);
            direction = theConsole.next().charAt(0);
        }
        while (!theMaze.getCurrentDoor(direction) && direction != '1' && direction != '2') {
            System.out.print("\nThere is no door in that direction, please try again.\n\n"
                    + room + prompt);
            direction = theConsole.next().charAt(0);
        }

        if (direction == '1'){
            FileMenu();
        }
        else if(direction == '2'){
            HelpMenu();
        }

        return direction;
    }


    public static void HelpMenu(){
        Scanner console = new Scanner(System.in);
        char choice;
        String prompt = "\nHelp\n" +
                "1.About \n2.Gameplay Instructions";
        System.out.println(prompt);
        choice  = console.nextLine().charAt(0);
        while (choice != '1' && choice != '2' && choice != '3') {
            System.out.println("Sorry, your input wasn't recognized. " + prompt);
            choice = console.next().charAt(0);
        }
        if(choice == '1'){
            displayAbout();
        }
        else if(choice == '2'){
            displayInstructions();
        }
    }

    public static void displayAbout(){
        System.out.println("\nABOUT:\nGameTitle:  TriviaMaze \nDevelopers: Killian Hickey, Tylor Franklin, Dino Jazvin\n");
        //getMove(new Scanner(System.in), TriviaMaze.test);
    }

    public static void displayInstructions(){
        System.out.println("\nGAMEPLAY INSTRUCTIONS:\nThe player must navigate the maze room-by-room. Each room is made up of multiple locked doors,\nin order to unlock a door" +
                " the question associated with that door must be answered correctly.\nWhen the end of the maze is reached the game is won. If the player " +
                "is unable to unlock any doors in a room the game is over.\n");
       // getMove(new Scanner(System.in));
    }


    public static void displayMenu(){
        System.out.println("***** MENU ******\n" + "1.File \n2.Help\n"  + "*****************\n");
    }

    public static void FileMenu(){
        Scanner console = new Scanner(System.in);
        char choice;
        String prompt ="\nFile\n" +
                "1.Save Game \n2.Load Game \n3.Exit";
        System.out.println(prompt);
        choice  = console.nextLine().charAt(0);
        while (choice != '1' && choice != '2' && choice != '3') {
            System.out.println("Sorry, your input wasn't recognized. " + prompt);
            choice = console.next().charAt(0);
        }
        if(choice == '1'){
            saveGame();
        }
        else if(choice == '2'){
            loadGame();
        }
        else
            exit();
    }

    public static void saveGame(){
        save = true;
    }

    public static boolean timeToSave(){
        return save;
    }

    public static void saveDone(){
        save = false;
    }

    public static void loadGame(){
        load = true;
    }

    public static boolean timeToLoad(){
        return load;
    }

    public static void loadDone(){
        load = false;
    }

    public static void exit() {
        System.exit(0);
    }


    /**
     * Prints a message telling the user they have completed the maze.
     */
    public static void printWinMessage() {
        System.out.println("\nThe door opens to reveal natural light on the other side. ");
        System.out.println("As you exit you begin to wonder about the nature of the maze, ");
        System.out.println("and what could've happened had you not been so clever. When you ");
        System.out.println("exit you turn back to see the door has vanished, you are able ");
        System.out.println("to walk free. You have won.");
    }

    /**
     * Prints a message telling the user they have failed in navigating the maze.
     */
    public static void lossMessage() {
        System.out.println(
                "\nAs you answer the question, you recognize your answer is wrong.");
        System.out.println(
                "Despite your pleas for another chance the door in front of you slowly ");
        System.out.println(
                "fades from view. Your chance to escape the maze has passed, and you are ");
        System.out.println(
                "stuck within the walls for the remainder of your days. You have lost.");
    }

    /**
     * Prompts the user when they have finished the maze to see if they would like
     * to play again. If yes the program will "restart". If no the program will
     * close.
     *
     * @param theConsole Scanner used for user input.
     * @return Returns a boolean signifying whether the user wants to play again.
     */
    public static boolean promptPlayAgain(Scanner theConsole) {
        System.out.print("Would you like to play again? (Y/N): ");
        boolean waitingOnAnswer = true;
        boolean wantsToPlay = true;
        String answer = "";
        while (waitingOnAnswer) {
            answer = theConsole.next();
            if (answer.equalsIgnoreCase("y") || answer.equalsIgnoreCase("n")) {
                waitingOnAnswer = false;
            } else {
                System.out.print("Input not understood, please answer Y or N: ");
            }
        }
        if (answer.equalsIgnoreCase("n")) {
            wantsToPlay = false;
        }
        return wantsToPlay;
    }
}
