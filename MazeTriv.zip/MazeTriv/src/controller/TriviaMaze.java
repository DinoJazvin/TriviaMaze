/*
 * TCSS 360
 *
 * Class containing the main method to run TriviaMaze.
 */
package controller;

import java.io.*;
import java.util.Scanner;

import model.Maze;

/**
 * Runs the maze game, and asks User if they want to play again afterward.
 * As well as saves and loads the game.
 *
 * @author Killian Hickey
 * @author Tylor Franklin
 * @author Dino Jazvin
 *
 * @version 5/29/2021
 */

public class TriviaMaze {

    public static void main(String[] args) {
        UserInput.printIntroduction();
        setUpMaze();
    }

    public static void setUpMaze() {
        int mazeSize = 4;
        Scanner console = new Scanner(System.in);
        boolean wantsToPlay = true;
            mazeSize = UserInput.mazeSize(console);
            Maze test = new Maze(mazeSize, mazeSize);
            playGame(test);
    }

    public static void playGame(Maze test) {
            Scanner console = new Scanner(System.in);
            boolean didWin = true;
            boolean solvable = true;
            boolean save = false;
            boolean load = false;
    // Actual Game loop
            while (didWin && solvable && !save && !load) {
                System.out.print(test.toString());
                test.checkDoor(UserInput.getMove(console, test));
                save = UserInput.timeToSave();
                load = UserInput.timeToLoad();
                didWin = test.winCondition();
                solvable = test.solvableMaze(test.getCurrentRow(), test.getCurrentCol());
            }
            if(save){
                Serialize(test, "file.ser");
            }
            else if(load){
                Deserialize("file.ser");
            }
            else if (didWin == false) {
                UserInput.printWinMessage();
            } else if (solvable == false) {
                UserInput.lossMessage();
            }
    // Win message and prompt user if they wish to play again
            if(UserInput.promptPlayAgain(console) == true) {
                setUpMaze();
            }
        }

    public static void Serialize(Maze myMaze, String fileName) {
        UserInput.saveDone();
        try {
            //Saving of object in a file
            FileOutputStream file = new FileOutputStream(fileName);
            ObjectOutputStream out = new ObjectOutputStream(file);

            // Method for serialization of object
            out.writeObject(myMaze);
            out.close();
            file.close();
            System.out.println("Save Successful.");
        }
        catch(IOException ex) {
            System.out.println(myMaze.toString());
            System.out.println("Save Unsuccessful");
        }
    }

    public static void Deserialize(String fileName) {
        UserInput.loadDone();
        Maze test1 = null;
        // Deserialization
        try {
            // Reading the object from a file
            FileInputStream file = new FileInputStream(fileName);
            ObjectInputStream in = new ObjectInputStream(file);

            //Casting object as Maze
            test1 = (Maze) in.readObject();
            in.close();
            file.close();
            System.out.println("Load Successful.");
        }

        catch(IOException ex) {
            System.out.println("Load Unsuccessful. IOException is caught");
        }
        catch(ClassNotFoundException ex) {
            System.out.println("Load Unsuccessful. ClassNotFoundException is caught");
        }
        playGame(test1);
    }



}












///*
// * TCSS 360
// *
// * Class containing the main method to run TriviaMaze.
// */
//package controller;
//
//import java.util.Scanner;
//
//import model.Maze;
//
///**
// * Runs the maze game, and asks User if they want to play again afterward.
// *
// * @author Killian Hickey
// * @author Tylor Franklin
// * @author Dino Jazvin
// *
// * @version 5/29/2021
// */
//
//public class TriviaMaze {
////    static boolean didWin;
////    static boolean solvable;
////    static boolean wantsToPlay;
//
//    public static void main(String[] args) {
//        Scanner console = new Scanner(System.in);
//        boolean wantsToPlay = true;
//        UserInput.printIntroduction();
//        int mazeSize = 4;
//// Outer loop so User continues playing until they answer no (N).
//        while (wantsToPlay) {
//            mazeSize = UserInput.mazeSize(console);
//
//            Maze test = new Maze(mazeSize, mazeSize);
////            didWin = true;
////             solvable = true;
//            boolean didWin = true;
//            boolean solvable = true;
//            boolean save = false;
//            boolean load = false;
//// Actual Game loop
//            while (didWin && solvable && !save && !load) {
//                //UserInput.displayMenu();
//                System.out.print(test.toString());
//                test.checkDoor(UserInput.getMove(console, test));
//                save = UserInput.timeToSave();
//                load = UserInput.timeToLoad();
//                didWin = test.winCondition();
//                solvable = test.solvableMaze(test.getCurrentRow(), test.getCurrentCol());
//            }
//            if(!save){
//                //Serialize this bitch!
//            }
//            else if(load){
//                //Deserialize this bitch!
//            }
//            else if (didWin == false) {
//                UserInput.printWinMessage();
//            } else if (solvable == false) {
//                UserInput.lossMessage();
//            }
//// Win message and prompt user if they wish to play again
//            wantsToPlay = UserInput.promptPlayAgain(console);
//        }
//    }
//
//}






